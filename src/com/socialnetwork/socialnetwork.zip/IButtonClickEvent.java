package com.socialnetwork;

import java.awt.event.ActionListener;

public interface IButtonClickEvent  {
    public void onClick();
}
